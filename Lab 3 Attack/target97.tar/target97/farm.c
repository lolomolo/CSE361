/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_420(unsigned x)
{
    return x + 2496104776U;
}

void setval_146(unsigned *p)
{
    *p = 2425393752U;
}

unsigned addval_451(unsigned x)
{
    return x + 482564096U;
}

unsigned addval_158(unsigned x)
{
    return x + 3284633928U;
}

void setval_387(unsigned *p)
{
    *p = 1460192088U;
}

unsigned getval_439()
{
    return 3284633928U;
}

unsigned getval_205()
{
    return 3260602295U;
}

void setval_398(unsigned *p)
{
    *p = 3351742792U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_493()
{
    return 3523789193U;
}

unsigned getval_480()
{
    return 3674789513U;
}

unsigned getval_269()
{
    return 3378563721U;
}

unsigned getval_133()
{
    return 3767027806U;
}

unsigned addval_307(unsigned x)
{
    return x + 3374367129U;
}

unsigned addval_127(unsigned x)
{
    return x + 3531921025U;
}

unsigned addval_116(unsigned x)
{
    return x + 2425405833U;
}

unsigned addval_120(unsigned x)
{
    return x + 3767027758U;
}

unsigned getval_260()
{
    return 3223377577U;
}

unsigned getval_400()
{
    return 3286272328U;
}

unsigned addval_196(unsigned x)
{
    return x + 3676357065U;
}

void setval_327(unsigned *p)
{
    *p = 3523264905U;
}

unsigned getval_253()
{
    return 3674265225U;
}

void setval_300(unsigned *p)
{
    *p = 3223372161U;
}

unsigned getval_176()
{
    return 2497743176U;
}

void setval_430(unsigned *p)
{
    *p = 2429159754U;
}

unsigned getval_168()
{
    return 3676359305U;
}

unsigned getval_337()
{
    return 3676883593U;
}

void setval_190(unsigned *p)
{
    *p = 3682910665U;
}

unsigned addval_479(unsigned x)
{
    return x + 3281049225U;
}

unsigned getval_448()
{
    return 2579745417U;
}

unsigned addval_105(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_267()
{
    return 3767093426U;
}

unsigned getval_311()
{
    return 3281049097U;
}

unsigned addval_404(unsigned x)
{
    return x + 3286272840U;
}

void setval_115(unsigned *p)
{
    *p = 3221804713U;
}

unsigned addval_306(unsigned x)
{
    return x + 3525364377U;
}

unsigned addval_170(unsigned x)
{
    return x + 2497743176U;
}

unsigned addval_257(unsigned x)
{
    return x + 3675832713U;
}

unsigned addval_325(unsigned x)
{
    return x + 3372796557U;
}

unsigned getval_109()
{
    return 3380926105U;
}

void setval_488(unsigned *p)
{
    *p = 2429200801U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
